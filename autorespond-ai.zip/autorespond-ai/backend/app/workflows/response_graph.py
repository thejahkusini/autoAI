"""LangGraph workflow for incoming customer replies.

START -> intent -> sentiment -> (conditional route)
   unsubscribe      -> optout   -> END     (no LLM, no RAG)
   callback_request -> callback -> END
   complaint        -> escalate -> END     (human takes over)
   product_*        -> retrieve -> respond -> END
   anything else    -> respond  -> END
"""
from functools import lru_cache
from typing import List, TypedDict

from langgraph.graph import END, START, StateGraph

from ..agents.intent_agent import classify_intent
from ..agents.response_agent import generate_reply
from ..agents.sentiment_agent import analyze_sentiment
from ..rag.retrieval import retrieve


class ReplyState(TypedDict, total=False):
    message: str
    campaign_id: int
    product_name: str
    channel: str
    intent: str
    confidence: float
    sentiment: str
    context: List[str]
    response: str
    action: str  # opt_out | create_callback | escalate | create_lead | none
    needs_human: bool


def intent_node(state: ReplyState):
    result = classify_intent(state["message"])
    return {"intent": result["intent"], "confidence": result["confidence"]}


def sentiment_node(state: ReplyState):
    return {"sentiment": analyze_sentiment(state["message"])}


def retrieve_node(state: ReplyState):
    query = f"{state.get('product_name', '')} {state['message']}"
    return {"context": retrieve(query, state.get("campaign_id"), k=4)}


def respond_node(state: ReplyState):
    intent = state["intent"]
    context = state.get("context", [])
    reply = generate_reply(
        state["message"], intent, state.get("sentiment", "neutral"),
        state.get("product_name", "our product"), context,
    )
    action = "create_lead" if intent == "product_interest" else "none"
    # Uncertain case: customer asked a product question but we found no knowledge -> human review
    needs_human = intent == "product_query" and not context
    return {"response": reply, "action": action, "needs_human": needs_human}


def optout_node(state: ReplyState):
    return {
        "response": "You've been unsubscribed and won't receive further promotional messages. Sorry to see you go.",
        "action": "opt_out",
        "needs_human": False,
    }


def callback_node(state: ReplyState):
    return {
        "response": "Happy to help! We've noted your request and a team member will call you soon.",
        "action": "create_callback",
        "needs_human": True,
    }


def escalate_node(state: ReplyState):
    return {
        "response": "We're sorry about your experience. Our support team has been notified and will contact you shortly.",
        "action": "escalate",
        "needs_human": True,
    }


def route_after_sentiment(state: ReplyState) -> str:
    intent = state["intent"]
    if intent == "unsubscribe":
        return "optout"
    if intent == "callback_request":
        return "callback"
    if intent == "complaint":
        return "escalate"
    if intent in ("product_query", "product_interest"):
        return "retrieve"
    return "respond"


@lru_cache(maxsize=1)
def get_reply_graph():
    g = StateGraph(ReplyState)
    g.add_node("intent", intent_node)
    g.add_node("sentiment", sentiment_node)
    g.add_node("retrieve", retrieve_node)
    g.add_node("respond", respond_node)
    g.add_node("optout", optout_node)
    g.add_node("callback", callback_node)
    g.add_node("escalate", escalate_node)

    g.add_edge(START, "intent")
    g.add_edge("intent", "sentiment")
    g.add_conditional_edges(
        "sentiment",
        route_after_sentiment,
        {"optout": "optout", "callback": "callback", "escalate": "escalate",
         "retrieve": "retrieve", "respond": "respond"},
    )
    g.add_edge("retrieve", "respond")
    for node in ("respond", "optout", "callback", "escalate"):
        g.add_edge(node, END)
    return g.compile()


def run_reply_workflow(message: str, campaign_id, product_name: str, channel: str) -> ReplyState:
    return get_reply_graph().invoke(
        {"message": message, "campaign_id": campaign_id, "product_name": product_name, "channel": channel}
    )
