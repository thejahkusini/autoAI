"""LangGraph workflow for campaign content: retrieve product facts -> generate -> validate."""
from functools import lru_cache
from typing import List, TypedDict

from langgraph.graph import END, START, StateGraph

from ..agents.campaign_agent import generate_campaign_content
from ..rag.retrieval import retrieve

CHANNEL_LIMITS = {"sms": 320, "whatsapp": 1000, "email": 5000}


class CampaignState(TypedDict, total=False):
    campaign_id: int
    name: str
    product_name: str
    objective: str
    audience: str
    channels: List[str]
    context: List[str]
    content: str
    warnings: List[str]


def retrieve_node(state: CampaignState):
    query = f"{state['product_name']} features price offers warranty"
    return {"context": retrieve(query, state["campaign_id"], k=5)}


def generate_node(state: CampaignState):
    text = generate_campaign_content(
        state["name"], state["product_name"], state.get("objective", ""),
        state.get("audience", ""), state.get("context", []),
    )
    return {"content": text}


def validate_node(state: CampaignState):
    warnings = []
    content = state["content"]
    if "stop" not in content.lower():
        content += "\nReply STOP to opt out."
    for ch in state.get("channels", []):
        limit = CHANNEL_LIMITS.get(ch)
        if limit and len(content) > limit:
            warnings.append(f"Content is {len(content)} chars; {ch} works best under {limit}.")
    if not state.get("context"):
        warnings.append("No product document found: claims in this copy are not grounded in your brochure.")
    return {"content": content, "warnings": warnings}


@lru_cache(maxsize=1)
def get_campaign_graph():
    g = StateGraph(CampaignState)
    g.add_node("retrieve", retrieve_node)
    g.add_node("generate", generate_node)
    g.add_node("validate", validate_node)
    g.add_edge(START, "retrieve")
    g.add_edge("retrieve", "generate")
    g.add_edge("generate", "validate")
    g.add_edge("validate", END)
    return g.compile()
