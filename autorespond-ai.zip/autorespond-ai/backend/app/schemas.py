from typing import List, Optional

from pydantic import BaseModel, Field


class RegisterIn(BaseModel):
    email: str
    password: str = Field(min_length=6)
    full_name: str = ""


class LoginIn(BaseModel):
    email: str
    password: str


class CampaignIn(BaseModel):
    name: str
    product_name: str
    objective: str = ""
    audience: str = ""
    channels: List[str] = ["email"]


class CampaignUpdate(BaseModel):
    name: Optional[str] = None
    objective: Optional[str] = None
    audience: Optional[str] = None
    channels: Optional[List[str]] = None
    content: Optional[str] = None


class CustomerIn(BaseModel):
    name: str = ""
    email: Optional[str] = None
    phone: Optional[str] = None
    consent: bool = False


class SimulateIn(BaseModel):
    campaign_id: Optional[int] = None
    channel: str = "whatsapp"
    sender: str  # email address or phone number
    message: str


class LeadUpdate(BaseModel):
    status: str
