import uuid

from ..config import settings


def send_sms(to: str, body: str) -> str:
    if settings.MESSAGING_MODE != "live":
        print(f"[MOCK SMS] to={to}\n{body}\n")
        return f"mock-{uuid.uuid4().hex[:10]}"
    from twilio.rest import Client

    client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
    return client.messages.create(from_=settings.TWILIO_SMS_FROM, to=to, body=body).sid
