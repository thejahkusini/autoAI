import smtplib
import uuid
from email.message import EmailMessage

from ..config import settings


def send_email(to: str, subject: str, body: str) -> str:
    if settings.MESSAGING_MODE != "live":
        print(f"[MOCK EMAIL] to={to} subject={subject}\n{body}\n")
        return f"mock-{uuid.uuid4().hex[:10]}"
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = settings.EMAIL_FROM, to, subject
    msg.set_content(body)
    with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
        server.starttls()
        server.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
        server.send_message(msg)
    return msg.get("Message-ID", uuid.uuid4().hex)
