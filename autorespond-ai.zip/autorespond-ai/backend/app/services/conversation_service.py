"""Handles one inbound customer message end-to-end (shared by webhooks and the dashboard simulator)."""
import re

from sqlalchemy.orm import Session

from ..agents.intent_agent import is_unsubscribe
from ..database.models import AuditLog, Campaign, Customer, Lead, Message
from ..workflows.response_graph import run_reply_workflow
from .messaging import send


def normalize_contact(value: str) -> str:
    value = value.strip()
    if value.lower().startswith("whatsapp:"):
        value = value[len("whatsapp:"):]
    if "@" in value:
        return value.lower()
    return re.sub(r"[^\d+]", "", value)


def find_or_create_customer(db: Session, channel: str, sender: str) -> Customer:
    contact = normalize_contact(sender)
    is_email = "@" in contact
    col = Customer.email if is_email else Customer.phone
    customer = db.query(Customer).filter(col == contact).first()
    if not customer:
        # Inbound contact we have not seen: created WITHOUT marketing consent.
        customer = Customer(name="Unknown", consent=False,
                            email=contact if is_email else None,
                            phone=None if is_email else contact)
        db.add(customer)
        db.commit()
        db.refresh(customer)
    return customer


def _open_lead(db: Session, campaign_id, customer_id, lead_type: str, note: str):
    exists = db.query(Lead).filter_by(
        campaign_id=campaign_id, customer_id=customer_id, lead_type=lead_type, status="open"
    ).first()
    if not exists:
        db.add(Lead(campaign_id=campaign_id, customer_id=customer_id, lead_type=lead_type, note=note))


def process_incoming(db: Session, channel: str, sender: str, text: str, campaign_id=None) -> dict:
    customer = find_or_create_customer(db, channel, sender)

    # 1) Immediate suppression: do not wait for the workflow or any LLM.
    if is_unsubscribe(text):
        customer.unsubscribed = True
        db.commit()

    # 2) Pick campaign: explicit -> last campaign we messaged this customer about -> newest campaign
    if campaign_id is None:
        last = db.query(Message).filter_by(customer_id=customer.id, direction="outbound") \
            .filter(Message.campaign_id.isnot(None)).order_by(Message.id.desc()).first()
        campaign_id = last.campaign_id if last else None
    campaign = db.get(Campaign, campaign_id) if campaign_id else db.query(Campaign).order_by(Campaign.id.desc()).first()
    campaign_id = campaign.id if campaign else None
    product = campaign.product_name if campaign else "our product"

    inbound = Message(campaign_id=campaign_id, customer_id=customer.id, channel=channel,
                      direction="inbound", content=text, status="received")
    db.add(inbound)
    db.commit()

    # 3) LangGraph workflow
    result = run_reply_workflow(text, campaign_id, product, channel)
    inbound.intent = result.get("intent")
    inbound.sentiment = result.get("sentiment")
    inbound.confidence = result.get("confidence")

    # 4) Apply the action chosen by the workflow
    action = result.get("action", "none")
    note = text[:300]
    if action == "opt_out":
        customer.unsubscribed = True
    elif action == "create_lead":
        _open_lead(db, campaign_id, customer.id, "interested", note)
    elif action == "create_callback":
        _open_lead(db, campaign_id, customer.id, "callback", note)
    elif action == "escalate":
        _open_lead(db, campaign_id, customer.id, "complaint", note)
    if result.get("needs_human") and action == "none":
        _open_lead(db, campaign_id, customer.id, "complaint", f"Needs human review: {note}")

    # 5) Send the reply (transactional reply to a customer-initiated message)
    reply = result.get("response", "")
    contact = customer.email if channel == "email" else customer.phone
    status, pid = ("failed", None)
    if reply and contact:
        status, pid = send(channel, contact, reply, subject="Re: your message")
    db.add(Message(campaign_id=campaign_id, customer_id=customer.id, channel=channel,
                   direction="outbound", content=reply, status=status, provider_id=pid))
    db.add(AuditLog(action="inbound_processed",
                    detail=f"customer={customer.id} intent={result.get('intent')} action={action}"))
    db.commit()

    return {
        "customer_id": customer.id,
        "campaign_id": campaign_id,
        "intent": result.get("intent"),
        "sentiment": result.get("sentiment"),
        "confidence": result.get("confidence"),
        "action": action,
        "needs_human": result.get("needs_human", False),
        "context_used": len(result.get("context", [])),
        "reply": reply,
    }
