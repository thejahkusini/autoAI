"""Sends a campaign to every eligible customer. Runs in a background task or a Celery worker."""
from ..database.connection import SessionLocal
from ..database.models import AuditLog, Campaign, Customer, Message
from .messaging import contact_for, send


def dispatch_campaign(campaign_id: int) -> dict:
    db = SessionLocal()
    sent = failed = skipped = 0
    try:
        campaign = db.get(Campaign, campaign_id)
        if not campaign:
            return {"error": "campaign not found"}
        # Consent + opt-out are checked at dispatch time, every time.
        customers = db.query(Customer).filter(
            Customer.consent.is_(True), Customer.unsubscribed.is_(False)
        ).all()
        for customer in customers:
            for channel in campaign.channels or []:
                to = contact_for(customer, channel)
                if not to:
                    continue
                already = db.query(Message).filter_by(
                    campaign_id=campaign.id, customer_id=customer.id,
                    channel=channel, direction="outbound",
                ).first()
                if already:  # duplicate prevention
                    skipped += 1
                    continue
                status, pid = send(channel, to, campaign.content, subject=campaign.name)
                db.add(Message(
                    campaign_id=campaign.id, customer_id=customer.id, channel=channel,
                    direction="outbound", content=campaign.content, status=status, provider_id=pid,
                ))
                db.commit()
                if status == "sent":
                    sent += 1
                else:
                    failed += 1
        campaign.status = "launched"
        db.add(AuditLog(action="campaign_dispatched",
                        detail=f"campaign={campaign.id} sent={sent} failed={failed} skipped={skipped}"))
        db.commit()
        return {"sent": sent, "failed": failed, "skipped": skipped}
    finally:
        db.close()
