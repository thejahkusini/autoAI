import uuid

from ..config import settings


def send_whatsapp(to: str, body: str) -> str:
    if settings.MESSAGING_MODE != "live":
        print(f"[MOCK WHATSAPP] to={to}\n{body}\n")
        return f"mock-{uuid.uuid4().hex[:10]}"
    from twilio.rest import Client

    client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
    dest = to if to.startswith("whatsapp:") else f"whatsapp:{to}"
    return client.messages.create(from_=settings.TWILIO_WHATSAPP_FROM, to=dest, body=body).sid
