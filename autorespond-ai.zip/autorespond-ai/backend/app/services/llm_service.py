"""Common LLM interface over Azure OpenAI, Gemini and Cohere (via LangChain), with fallback."""
import json
import re
from functools import lru_cache
from typing import Optional

from ..config import settings


def is_mock() -> bool:
    return settings.LLM_PROVIDER == "mock"


@lru_cache(maxsize=4)
def get_llm(provider: str):
    if provider == "azure":
        from langchain_openai import AzureChatOpenAI

        return AzureChatOpenAI(
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_key=settings.AZURE_OPENAI_API_KEY,
            api_version=settings.AZURE_OPENAI_API_VERSION,
            azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT,
            temperature=0.3,
        )
    if provider == "gemini":
        from langchain_google_genai import ChatGoogleGenerativeAI

        return ChatGoogleGenerativeAI(
            model=settings.GEMINI_MODEL, google_api_key=settings.GOOGLE_API_KEY, temperature=0.3
        )
    if provider == "cohere":
        from langchain_cohere import ChatCohere

        return ChatCohere(
            model=settings.COHERE_MODEL, cohere_api_key=settings.COHERE_API_KEY, temperature=0.3
        )
    raise ValueError(f"Unsupported LLM provider: {provider}")


def _text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):  # some providers return content blocks
        return "".join(p if isinstance(p, str) else p.get("text", "") for p in content)
    return str(content)


def generate(system: str, user: str) -> Optional[str]:
    """Return LLM text, or None if provider is `mock` or every provider failed."""
    if is_mock():
        return None
    providers = [settings.LLM_PROVIDER]
    if settings.LLM_FALLBACK_PROVIDER and settings.LLM_FALLBACK_PROVIDER != "mock":
        providers.append(settings.LLM_FALLBACK_PROVIDER)
    for provider in providers:
        try:
            llm = get_llm(provider)
            result = llm.invoke([("system", system), ("human", user)])
            return _text(result.content).strip()
        except Exception as exc:  # retry with fallback provider
            print(f"[llm] {provider} failed: {exc}")
    return None


def generate_json(system: str, user: str) -> Optional[dict]:
    raw = generate(system, user)
    if not raw:
        return None
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if not match:
        return None
    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError:
        return None
