"""Single entry point for sending on any channel."""
from typing import Optional, Tuple

from .email_service import send_email
from .sms_service import send_sms
from .whatsapp_service import send_whatsapp

CHANNELS = ("email", "whatsapp", "sms")


def contact_for(customer, channel: str) -> Optional[str]:
    return customer.email if channel == "email" else customer.phone


def send(channel: str, to: str, body: str, subject: str = "A message from us") -> Tuple[str, Optional[str]]:
    """Returns (status, provider_id). Never raises: failures are recorded as status='failed'."""
    try:
        if channel == "email":
            pid = send_email(to, subject, body)
        elif channel == "whatsapp":
            pid = send_whatsapp(to, body)
        elif channel == "sms":
            pid = send_sms(to, body)
        else:
            return "failed", None
        return "sent", pid
    except Exception as exc:
        print(f"[messaging] {channel} send failed: {exc}")
        return "failed", None
