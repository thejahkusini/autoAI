from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text

from .connection import Base


def utcnow():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    full_name = Column(String(255), default="")
    hashed_password = Column(String(512), nullable=False)
    role = Column(String(30), default="marketer")  # admin | marketer
    created_at = Column(DateTime, default=utcnow)


class Campaign(Base):
    __tablename__ = "campaigns"
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    product_name = Column(String(255), nullable=False)
    objective = Column(Text, default="")
    audience = Column(Text, default="")
    channels = Column(JSON, default=list)  # ["email", "whatsapp", "sms"]
    content = Column(Text, default="")
    status = Column(String(30), default="draft")  # draft | approved | launched
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow)


class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), index=True)
    filename = Column(String(255))
    path = Column(String(512))
    chunk_count = Column(Integer, default=0)
    status = Column(String(30), default="processed")
    created_at = Column(DateTime, default=utcnow)


class Customer(Base):
    __tablename__ = "customers"
    id = Column(Integer, primary_key=True)
    name = Column(String(255), default="")
    email = Column(String(255), index=True, nullable=True)
    phone = Column(String(50), index=True, nullable=True)
    consent = Column(Boolean, default=False)
    unsubscribed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utcnow)


class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), index=True, nullable=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), index=True)
    channel = Column(String(20))
    direction = Column(String(10))  # outbound | inbound
    content = Column(Text)
    intent = Column(String(40), nullable=True)
    sentiment = Column(String(20), nullable=True)
    confidence = Column(Float, nullable=True)
    status = Column(String(20), default="sent")  # sent | failed | received
    provider_id = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=utcnow)


class Lead(Base):
    __tablename__ = "leads"
    id = Column(Integer, primary_key=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), index=True, nullable=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), index=True)
    lead_type = Column(String(30))  # interested | callback | complaint
    note = Column(Text, default="")
    status = Column(String(20), default="open")  # open | contacted | closed
    created_at = Column(DateTime, default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, nullable=True)
    action = Column(String(100))
    detail = Column(Text, default="")
    created_at = Column(DateTime, default=utcnow)
