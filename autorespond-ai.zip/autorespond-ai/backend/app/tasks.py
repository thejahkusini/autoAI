"""Optional Celery worker. Enable with USE_CELERY=true and run:
   celery -A app.tasks.celery_app worker --loglevel=info --pool=solo
"""
from celery import Celery

from .config import settings

celery_app = Celery("autorespond", broker=settings.REDIS_URL, backend=settings.REDIS_URL)


@celery_app.task(name="launch_campaign")
def launch_campaign_task(campaign_id: int):
    from .services.campaign_runner import dispatch_campaign

    return dispatch_campaign(campaign_id)
