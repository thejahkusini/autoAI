from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api import analytics, auth, campaigns, customers, documents, leads, messages, webhooks
from .config import settings
from .database import models  # noqa: F401  (registers tables)
from .database.connection import Base, engine


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)  # simple bootstrap; use Alembic migrations in production
    yield


app = FastAPI(title="AutoRespond.ai", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_ORIGIN, "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for module in (auth, campaigns, documents, customers, messages, leads, analytics, webhooks):
    app.include_router(module.router)


@app.get("/api/health")
def health():
    return {"status": "ok", "llm_provider": settings.LLM_PROVIDER,
            "embedding_provider": settings.EMBEDDING_PROVIDER, "messaging_mode": settings.MESSAGING_MODE}
