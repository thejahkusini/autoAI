"""Embedding providers. `mock` is an offline hashing embedder so the app runs without API keys."""
import hashlib
import math
import re
from functools import lru_cache
from typing import List

from langchain_core.embeddings import Embeddings

from ..config import settings


class HashEmbeddings(Embeddings):
    """Deterministic bag-of-words embedder (signed feature hashing). Good enough for demos/tests."""

    dim = 384

    def _embed(self, text: str) -> List[float]:
        vec = [0.0] * self.dim
        for tok in re.findall(r"[a-z0-9]+", text.lower()):
            h = int(hashlib.md5(tok.encode()).hexdigest(), 16)
            vec[h % self.dim] += 1.0 if (h >> 8) & 1 else -1.0
        norm = math.sqrt(sum(v * v for v in vec)) or 1.0
        return [v / norm for v in vec]

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return [self._embed(t) for t in texts]

    def embed_query(self, text: str) -> List[float]:
        return self._embed(text)


@lru_cache(maxsize=1)
def get_embeddings() -> Embeddings:
    provider = settings.EMBEDDING_PROVIDER
    if provider == "mock":
        return HashEmbeddings()
    if provider == "azure":
        from langchain_openai import AzureOpenAIEmbeddings

        return AzureOpenAIEmbeddings(
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_key=settings.AZURE_OPENAI_API_KEY,
            api_version=settings.AZURE_OPENAI_API_VERSION,
            azure_deployment=settings.AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
        )
    if provider == "gemini":
        from langchain_google_genai import GoogleGenerativeAIEmbeddings

        return GoogleGenerativeAIEmbeddings(
            model=settings.GEMINI_EMBEDDING_MODEL, google_api_key=settings.GOOGLE_API_KEY
        )
    if provider == "cohere":
        from langchain_cohere import CohereEmbeddings

        return CohereEmbeddings(
            model=settings.COHERE_EMBEDDING_MODEL, cohere_api_key=settings.COHERE_API_KEY
        )
    raise ValueError(f"Unsupported EMBEDDING_PROVIDER: {provider}")
