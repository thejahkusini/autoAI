"""Vector store access (ChromaDB). Every chunk carries campaign_id/document_id metadata so
retrieval for one campaign never sees another campaign's documents."""
from functools import lru_cache
from typing import List

from langchain_chroma import Chroma

from ..config import settings
from .embeddings import get_embeddings


@lru_cache(maxsize=1)
def get_vectorstore() -> Chroma:
    return Chroma(
        collection_name=f"product_knowledge_{settings.EMBEDDING_PROVIDER}",
        embedding_function=get_embeddings(),
        persist_directory=settings.CHROMA_DIR,
    )


def add_chunks(chunks: List[str], campaign_id: int, document_id: int, filename: str) -> int:
    if not chunks:
        return 0
    metadatas = [
        {"campaign_id": campaign_id, "document_id": document_id, "chunk": i, "source": filename}
        for i in range(len(chunks))
    ]
    ids = [f"doc{document_id}-chunk{i}" for i in range(len(chunks))]
    get_vectorstore().add_texts(texts=chunks, metadatas=metadatas, ids=ids)
    return len(chunks)


def delete_document_chunks(document_id: int) -> None:
    try:
        get_vectorstore()._collection.delete(where={"document_id": document_id})
    except Exception:
        pass


def retrieve(query: str, campaign_id: int | None, k: int = 4) -> List[str]:
    if campaign_id is None:
        return []
    try:
        docs = get_vectorstore().similarity_search(
            query, k=k, filter={"campaign_id": campaign_id}
        )
    except Exception:
        return []
    return [d.page_content for d in docs]
