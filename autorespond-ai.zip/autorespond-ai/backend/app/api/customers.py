import csv
import io

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from ..database.connection import get_db
from ..database.models import Customer, User
from ..schemas import CustomerIn
from ..security import get_current_user
from ..services.conversation_service import normalize_contact
from .utils import to_dict

router = APIRouter(prefix="/api/customers", tags=["customers"])


@router.post("")
def add_customer(body: CustomerIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if not body.email and not body.phone:
        raise HTTPException(400, "Provide an email or a phone number")
    customer = Customer(name=body.name,
                        email=normalize_contact(body.email) if body.email else None,
                        phone=normalize_contact(body.phone) if body.phone else None,
                        consent=body.consent)
    db.add(customer)
    db.commit()
    db.refresh(customer)
    return to_dict(customer)


@router.get("")
def list_customers(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return [to_dict(c) for c in db.query(Customer).order_by(Customer.id.desc()).all()]


@router.post("/import")
def import_csv(file: UploadFile = File(...), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """CSV columns: name,email,phone,consent  (consent must be yes/true/1, otherwise no consent is recorded)."""
    rows = csv.DictReader(io.StringIO(file.file.read().decode("utf-8-sig")))
    created = 0
    for row in rows:
        email, phone = (row.get("email") or "").strip(), (row.get("phone") or "").strip()
        if not email and not phone:
            continue
        consent = (row.get("consent") or "").strip().lower() in ("yes", "true", "1", "y")
        db.add(Customer(name=(row.get("name") or "").strip(),
                        email=normalize_contact(email) if email else None,
                        phone=normalize_contact(phone) if phone else None, consent=consent))
        created += 1
    db.commit()
    return {"imported": created}


@router.patch("/{customer_id}/consent")
def set_consent(customer_id: int, consent: bool, db: Session = Depends(get_db),
                user: User = Depends(get_current_user)):
    customer = db.get(Customer, customer_id)
    if not customer:
        raise HTTPException(404, "Customer not found")
    customer.consent = consent
    db.commit()
    return to_dict(customer)
