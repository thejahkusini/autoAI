from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database.connection import get_db
from ..database.models import Campaign, Customer, Lead, User
from ..schemas import LeadUpdate
from ..security import get_current_user
from .utils import to_dict

router = APIRouter(prefix="/api/leads", tags=["leads"])


@router.get("")
def list_leads(lead_type: str | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = db.query(Lead, Customer, Campaign).join(Customer, Customer.id == Lead.customer_id) \
        .outerjoin(Campaign, Campaign.id == Lead.campaign_id)
    if lead_type:
        q = q.filter(Lead.lead_type == lead_type)
    out = []
    for lead, cust, camp in q.order_by(Lead.id.desc()).all():
        d = to_dict(lead)
        d.update(customer_name=cust.name, customer_email=cust.email, customer_phone=cust.phone,
                 campaign_name=camp.name if camp else None)
        out.append(d)
    return out


@router.patch("/{lead_id}")
def update_lead(lead_id: int, body: LeadUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    lead = db.get(Lead, lead_id)
    if not lead:
        raise HTTPException(404, "Lead not found")
    if body.status not in ("open", "contacted", "closed"):
        raise HTTPException(400, "Status must be open, contacted or closed")
    lead.status = body.status
    db.commit()
    return to_dict(lead)
