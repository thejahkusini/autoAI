from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy.orm import Session

from ..config import settings
from ..database.connection import get_db
from ..database.models import AuditLog, Campaign, Customer, User
from ..schemas import CampaignIn, CampaignUpdate
from ..security import get_current_user
from ..services.campaign_runner import dispatch_campaign
from ..services.messaging import CHANNELS
from ..workflows.campaign_graph import get_campaign_graph
from .utils import to_dict

router = APIRouter(prefix="/api/campaigns", tags=["campaigns"])


def _get(db: Session, campaign_id: int) -> Campaign:
    campaign = db.get(Campaign, campaign_id)
    if not campaign:
        raise HTTPException(404, "Campaign not found")
    return campaign


@router.post("")
def create_campaign(body: CampaignIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    channels = [c for c in body.channels if c in CHANNELS]
    if not channels:
        raise HTTPException(400, "Choose at least one channel: email, whatsapp or sms")
    campaign = Campaign(name=body.name, product_name=body.product_name, objective=body.objective,
                        audience=body.audience, channels=channels, created_by=user.id)
    db.add(campaign)
    db.add(AuditLog(user_id=user.id, action="campaign_created", detail=body.name))
    db.commit()
    db.refresh(campaign)
    return to_dict(campaign)


@router.get("")
def list_campaigns(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return [to_dict(c) for c in db.query(Campaign).order_by(Campaign.id.desc()).all()]


@router.get("/{campaign_id}")
def get_campaign(campaign_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return to_dict(_get(db, campaign_id))


@router.put("/{campaign_id}")
def update_campaign(campaign_id: int, body: CampaignUpdate, db: Session = Depends(get_db),
                    user: User = Depends(get_current_user)):
    campaign = _get(db, campaign_id)
    if campaign.status == "launched":
        raise HTTPException(400, "A launched campaign can't be edited")
    for key, value in body.model_dump(exclude_none=True).items():
        setattr(campaign, key, value)
    if body.content is not None:
        campaign.status = "draft"  # edited content must be re-approved
    db.commit()
    return to_dict(campaign)


@router.post("/{campaign_id}/generate-content")
def generate_content(campaign_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    campaign = _get(db, campaign_id)
    result = get_campaign_graph().invoke({
        "campaign_id": campaign.id, "name": campaign.name, "product_name": campaign.product_name,
        "objective": campaign.objective, "audience": campaign.audience, "channels": campaign.channels,
    })
    campaign.content = result["content"]
    campaign.status = "draft"
    db.commit()
    return {"content": campaign.content, "warnings": result.get("warnings", [])}


@router.post("/{campaign_id}/approve")
def approve(campaign_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    campaign = _get(db, campaign_id)
    if not campaign.content.strip():
        raise HTTPException(400, "Generate or write content before approving")
    campaign.status = "approved"
    db.add(AuditLog(user_id=user.id, action="campaign_approved", detail=str(campaign.id)))
    db.commit()
    return to_dict(campaign)


@router.post("/{campaign_id}/launch")
def launch(campaign_id: int, background: BackgroundTasks, db: Session = Depends(get_db),
           user: User = Depends(get_current_user)):
    campaign = _get(db, campaign_id)
    if campaign.status != "approved":
        raise HTTPException(400, "Approve the campaign content before launching")
    eligible = db.query(Customer).filter(Customer.consent.is_(True), Customer.unsubscribed.is_(False)).count()
    if eligible == 0:
        raise HTTPException(400, "No eligible customers: add customers who have given consent")
    db.add(AuditLog(user_id=user.id, action="campaign_launch_requested", detail=str(campaign.id)))
    db.commit()
    if settings.USE_CELERY:
        from ..tasks import launch_campaign_task

        launch_campaign_task.delay(campaign.id)
    else:
        background.add_task(dispatch_campaign, campaign.id)
    return {"status": "launching", "eligible_customers": eligible}
