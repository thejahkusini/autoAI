from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from sqlalchemy.orm import Session

from ..config import settings
from ..database.connection import get_db
from ..services.conversation_service import process_incoming
from ..services.messaging import CHANNELS

router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])


@router.post("/{channel}")
async def inbound_webhook(channel: str, request: Request, db: Session = Depends(get_db)):
    """Receives customer replies. Accepts JSON {from, message} or Twilio-style form {From, Body}.
    In production also verify the provider's signature (e.g. Twilio X-Twilio-Signature)."""
    if channel not in CHANNELS:
        raise HTTPException(404, "Unknown channel")
    if settings.WEBHOOK_SECRET and request.headers.get("x-webhook-secret") != settings.WEBHOOK_SECRET:
        raise HTTPException(401, "Bad webhook secret")

    if "json" in request.headers.get("content-type", ""):
        data = await request.json()
    else:
        data = dict(await request.form())
    sender = data.get("from") or data.get("From") or data.get("sender")
    text = data.get("message") or data.get("Body") or data.get("text")
    if not sender or not text:
        raise HTTPException(400, "Missing sender or message")
    raw_campaign = data.get("campaign_id")
    campaign_id = int(raw_campaign) if str(raw_campaign or "").isdigit() else None
    result = await run_in_threadpool(process_incoming, db, channel, str(sender), str(text), campaign_id)
    return {"status": "processed", "intent": result["intent"], "action": result["action"]}
