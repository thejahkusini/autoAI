from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..database.connection import get_db
from ..database.models import Campaign, Customer, Lead, Message, User
from ..security import get_current_user

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


def _count_by(db, column, *filters):
    q = db.query(column, func.count()).filter(column.isnot(None))
    for f in filters:
        q = q.filter(f)
    return {k: v for k, v in q.group_by(column).all()}


@router.get("")
def analytics(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    outbound = Message.direction == "outbound"
    inbound = Message.direction == "inbound"
    campaigns = []
    for c in db.query(Campaign).order_by(Campaign.id.desc()).all():
        base = db.query(func.count(Message.id)).filter(Message.campaign_id == c.id)
        campaigns.append({
            "id": c.id, "name": c.name, "status": c.status,
            "sent": base.filter(outbound, Message.status == "sent").scalar(),
            "failed": base.filter(outbound, Message.status == "failed").scalar(),
            "replies": base.filter(inbound).scalar(),
            "leads": db.query(func.count(Lead.id)).filter(Lead.campaign_id == c.id).scalar(),
        })
    return {
        "totals": {
            "campaigns": db.query(func.count(Campaign.id)).scalar(),
            "customers": db.query(func.count(Customer.id)).scalar(),
            "unsubscribed": db.query(func.count(Customer.id)).filter(Customer.unsubscribed.is_(True)).scalar(),
            "messages_sent": db.query(func.count(Message.id)).filter(outbound, Message.status == "sent").scalar(),
            "replies": db.query(func.count(Message.id)).filter(inbound).scalar(),
            "open_leads": db.query(func.count(Lead.id)).filter(Lead.status == "open").scalar(),
        },
        "leads_by_type": _count_by(db, Lead.lead_type),
        "intents": _count_by(db, Message.intent, inbound),
        "sentiments": _count_by(db, Message.sentiment, inbound),
        "channels": _count_by(db, Message.channel, outbound),
        "campaigns": campaigns,
    }
