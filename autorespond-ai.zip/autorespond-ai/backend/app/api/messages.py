from fastapi import APIRouter, Depends, HTTPException
from fastapi.concurrency import run_in_threadpool
from sqlalchemy.orm import Session

from ..database.connection import get_db
from ..database.models import Customer, Message, User
from ..schemas import SimulateIn
from ..security import get_current_user
from ..services.conversation_service import process_incoming
from ..services.messaging import CHANNELS
from .utils import to_dict

router = APIRouter(prefix="/api/messages", tags=["messages"])


@router.get("")
def list_messages(campaign_id: int | None = None, customer_id: int | None = None, limit: int = 100,
                  db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = db.query(Message, Customer).join(Customer, Customer.id == Message.customer_id)
    if campaign_id:
        q = q.filter(Message.campaign_id == campaign_id)
    if customer_id:
        q = q.filter(Message.customer_id == customer_id)
    rows = q.order_by(Message.id.desc()).limit(min(limit, 500)).all()
    out = []
    for msg, cust in rows:
        d = to_dict(msg)
        d["customer_name"] = cust.name or cust.email or cust.phone
        out.append(d)
    return out


@router.post("/simulate-reply")
async def simulate_reply(body: SimulateIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Dashboard test tool: behaves exactly like a real webhook."""
    if body.channel not in CHANNELS:
        raise HTTPException(400, "Unknown channel")
    if not body.message.strip():
        raise HTTPException(400, "Message is empty")
    return await run_in_threadpool(process_incoming, db, body.channel, body.sender, body.message, body.campaign_id)
