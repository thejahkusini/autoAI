import shutil
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from ..config import settings
from ..database.connection import get_db
from ..database.models import AuditLog, Campaign, Document, User
from ..rag.ingestion import chunk_text, extract_text
from ..rag.retrieval import add_chunks, delete_document_chunks, retrieve
from ..security import get_current_user
from .utils import to_dict

router = APIRouter(prefix="/api/documents", tags=["documents"])
ALLOWED = {".pdf", ".docx", ".txt", ".md"}
MAX_BYTES = 15 * 1024 * 1024


@router.post("/upload")
def upload_document(campaign_id: int = Form(...), file: UploadFile = File(...),
                    db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if not db.get(Campaign, campaign_id):
        raise HTTPException(404, "Campaign not found")
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED:
        raise HTTPException(400, "Upload a PDF, DOCX or TXT file")
    saved = settings.UPLOAD_DIR / f"{uuid.uuid4().hex}{ext}"
    with open(saved, "wb") as out:
        shutil.copyfileobj(file.file, out)
    if saved.stat().st_size > MAX_BYTES:
        saved.unlink(missing_ok=True)
        raise HTTPException(400, "File is larger than 15 MB")

    doc = Document(campaign_id=campaign_id, filename=file.filename, path=str(saved), status="processing")
    db.add(doc)
    db.commit()
    db.refresh(doc)
    try:
        text = extract_text(str(saved))
        chunks = chunk_text(text)
        if not chunks:
            raise ValueError("No readable text found in this file (scanned PDFs need OCR)")
        doc.chunk_count = add_chunks(chunks, campaign_id, doc.id, file.filename)
        doc.status = "processed"
    except Exception as exc:
        doc.status = "failed"
        db.commit()
        raise HTTPException(422, f"Could not process document: {exc}")
    db.add(AuditLog(user_id=user.id, action="document_uploaded", detail=f"{file.filename} campaign={campaign_id}"))
    db.commit()
    return to_dict(doc)


@router.get("")
def list_documents(campaign_id: int | None = None, db: Session = Depends(get_db),
                   user: User = Depends(get_current_user)):
    q = db.query(Document)
    if campaign_id:
        q = q.filter(Document.campaign_id == campaign_id)
    return [to_dict(d) for d in q.order_by(Document.id.desc()).all()]


@router.delete("/{document_id}")
def delete_document(document_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    doc = db.get(Document, document_id)
    if not doc:
        raise HTTPException(404, "Document not found")
    delete_document_chunks(doc.id)
    Path(doc.path).unlink(missing_ok=True)
    db.delete(doc)
    db.commit()
    return {"deleted": document_id}


@router.get("/search")
def search_knowledge(campaign_id: int, q: str, user: User = Depends(get_current_user)):
    """Debug helper: see which chunks RAG would retrieve for a question."""
    return {"chunks": retrieve(q, campaign_id, k=4)}
