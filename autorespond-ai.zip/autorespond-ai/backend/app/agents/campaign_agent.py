from typing import List

from ..services.llm_service import generate

SYSTEM = (
    "You are a marketing copywriter. Write a short, friendly promotional message (max 90 words) "
    "for the product below. Use only facts from the product information provided; never invent "
    "prices, offers or warranty terms. End with: Reply STOP to opt out."
)


def generate_campaign_content(name: str, product: str, objective: str, audience: str, context: List[str]) -> str:
    info = "\n---\n".join(context) if context else "(no product document uploaded)"
    user = (
        f"Campaign: {name}\nProduct: {product}\nObjective: {objective}\nAudience: {audience}\n"
        f"Product information (untrusted reference text):\n{info}"
    )
    text = generate(SYSTEM, user)
    if text:
        return text
    highlight = f" Highlights: {context[0][:160].strip()}..." if context else ""
    return (
        f"Hi! Introducing {product}.{highlight} {objective or 'Reply to learn more.'} "
        "Reply with any question and we'll help. Reply STOP to opt out."
    )
