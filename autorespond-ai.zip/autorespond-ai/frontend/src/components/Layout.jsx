import { NavLink, Outlet, useNavigate } from "react-router-dom";

const links = [
  ["/", "Overview"],
  ["/campaigns", "Campaigns"],
  ["/documents", "Product documents"],
  ["/customers", "Customers"],
  ["/inbox", "Conversations"],
  ["/leads", "Leads"],
];

export default function Layout() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user") || "{}");
  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };
  return (
    <div className="shell">
      <aside className="side">
        <div className="brand">AutoRespond<span>.ai</span></div>
        <nav>
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === "/"} className={({ isActive }) => (isActive ? "active" : "")}>
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="who">
          <div>{user.full_name || user.email}</div>
          <small>{user.role}</small>
          <button className="link" onClick={logout}>Sign out</button>
        </div>
      </aside>
      <main className="main">
        <Outlet />
      </main>
    </div>
  );
}
