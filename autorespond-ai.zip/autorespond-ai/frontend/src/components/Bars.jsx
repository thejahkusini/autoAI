export default function Bars({ data, empty = "No data yet" }) {
  const entries = Object.entries(data || {});
  if (!entries.length) return <p className="muted">{empty}</p>;
  const max = Math.max(...entries.map(([, v]) => v));
  return (
    <div className="bars">
      {entries.map(([k, v]) => (
        <div className="bar-row" key={k}>
          <span>{k.replaceAll("_", " ")}</span>
          <div className="bar"><i style={{ width: `${(v / max) * 100}%` }} /></div>
          <b>{v}</b>
        </div>
      ))}
    </div>
  );
}
