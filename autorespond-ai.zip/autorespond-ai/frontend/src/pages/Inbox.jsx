import { useEffect, useState } from "react";
import api, { errorMessage } from "../services/api";

export default function Inbox() {
  const [campaigns, setCampaigns] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [form, setForm] = useState({ campaign_id: "", channel: "whatsapp", sender: "", message: "" });
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const loadMessages = () => api.get("/api/messages?limit=60").then((r) => setMessages(r.data));
  useEffect(() => {
    api.get("/api/campaigns").then((r) => {
      setCampaigns(r.data);
      if (r.data[0]) setForm((f) => ({ ...f, campaign_id: String(r.data[0].id) }));
    });
    api.get("/api/customers").then((r) => setCustomers(r.data));
    loadMessages();
  }, []);

  const send = async (e) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const { data } = await api.post("/api/messages/simulate-reply", {
        ...form,
        campaign_id: form.campaign_id ? Number(form.campaign_id) : null,
      });
      setResult(data);
      setForm({ ...form, message: "" });
      loadMessages();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const pick = (c) => c && setForm({ ...form, sender: form.channel === "email" ? c.email || "" : c.phone || "" });

  return (
    <>
      <h2>Conversations</h2>
      <form className="panel" onSubmit={send}>
        <h3>Simulate a customer reply</h3>
        <p className="muted">This runs the same workflow as a real WhatsApp, SMS or email webhook.</p>
        <div className="grid2">
          <label>Campaign
            <select value={form.campaign_id} onChange={(e) => setForm({ ...form, campaign_id: e.target.value })}>
              {campaigns.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </label>
          <label>Channel
            <select value={form.channel} onChange={(e) => setForm({ ...form, channel: e.target.value })}>
              <option>whatsapp</option><option>sms</option><option>email</option>
            </select>
          </label>
          <label>Pick a customer
            <select onChange={(e) => pick(customers.find((c) => String(c.id) === e.target.value))} defaultValue="">
              <option value="">Choose…</option>
              {customers.map((c) => <option key={c.id} value={c.id}>{c.name || c.email || c.phone}</option>)}
            </select>
          </label>
          <label>Sender (phone or email)<input required value={form.sender} onChange={(e) => setForm({ ...form, sender: e.target.value })} /></label>
        </div>
        <label>Customer message
          <textarea rows={3} required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })}
            placeholder="Does this TV come with a 2-year warranty?" />
        </label>
        {error && <div className="error">{error}</div>}
        <button className="primary" disabled={busy}>{busy ? "Thinking…" : "Send reply"}</button>
        {result && (
          <div className="result">
            <div className="row">
              <span className="tag">{result.intent?.replaceAll("_", " ")}</span>
              <span className="tag">{result.sentiment}</span>
              <span className="tag">action: {result.action.replaceAll("_", " ")}</span>
              {result.needs_human && <span className="tag failed">needs a person</span>}
            </div>
            <p><b>AI reply:</b> {result.reply}</p>
          </div>
        )}
      </form>
      <section className="panel">
        <h3>Recent messages</h3>
        {messages.length === 0 ? <p className="muted">No messages yet.</p> : (
          <div className="thread">
            {messages.map((m) => (
              <div key={m.id} className={`bubble ${m.direction}`}>
                <small>{m.customer_name} · {m.channel} · {m.direction}{m.intent ? ` · ${m.intent.replaceAll("_", " ")}` : ""}</small>
                <p>{m.content}</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </>
  );
}
