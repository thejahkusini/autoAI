import { useEffect, useState } from "react";
import api, { errorMessage } from "../services/api";

const CHANNELS = ["email", "whatsapp", "sms"];
const blank = { name: "", product_name: "", objective: "", audience: "", channels: ["email"] };

function CampaignCard({ campaign, onChange }) {
  const [content, setContent] = useState(campaign.content || "");
  const [notes, setNotes] = useState([]);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const locked = campaign.status === "launched";

  const run = async (fn, done) => {
    setBusy(true);
    setMsg("");
    try {
      await fn();
      if (done) setMsg(done);
      onChange();
    } catch (err) {
      setMsg(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const generate = () =>
    run(async () => {
      const { data } = await api.post(`/api/campaigns/${campaign.id}/generate-content`);
      setContent(data.content);
      setNotes(data.warnings);
    });
  const save = () => run(() => api.put(`/api/campaigns/${campaign.id}`, { content }), "Saved. Approve again before launching.");
  const approve = () => run(() => api.post(`/api/campaigns/${campaign.id}/approve`), "Approved.");
  const launch = () =>
    run(async () => {
      const { data } = await api.post(`/api/campaigns/${campaign.id}/launch`);
      setMsg(`Launching to ${data.eligible_customers} customers with consent.`);
    });

  return (
    <section className="panel">
      <div className="row between">
        <div>
          <h3>{campaign.name}</h3>
          <p className="muted">{campaign.product_name} · {campaign.channels.join(", ")}</p>
        </div>
        <span className={`tag ${campaign.status}`}>{campaign.status}</span>
      </div>
      <label>Message
        <textarea rows={5} disabled={locked} value={content} onChange={(e) => setContent(e.target.value)}
          placeholder="Generate copy from your product document, or write your own." />
      </label>
      {notes.map((n) => <div className="warn" key={n}>{n}</div>)}
      {msg && <div className="note">{msg}</div>}
      {!locked && (
        <div className="row">
          <button disabled={busy} onClick={generate}>Generate message</button>
          <button disabled={busy || content === campaign.content} onClick={save}>Save edits</button>
          <button disabled={busy || !campaign.content || campaign.status !== "draft"} onClick={approve}>Approve</button>
          <button className="primary" disabled={busy || campaign.status !== "approved"} onClick={launch}>Launch campaign</button>
        </div>
      )}
    </section>
  );
}

export default function Campaigns() {
  const [list, setList] = useState([]);
  const [form, setForm] = useState(blank);
  const [error, setError] = useState("");

  const load = () => api.get("/api/campaigns").then((r) => setList(r.data));
  useEffect(() => { load(); }, []);

  const toggle = (ch) =>
    setForm({ ...form, channels: form.channels.includes(ch) ? form.channels.filter((c) => c !== ch) : [...form.channels, ch] });

  const create = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await api.post("/api/campaigns", form);
      setForm(blank);
      load();
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  return (
    <>
      <h2>Campaigns</h2>
      <form className="panel" onSubmit={create}>
        <h3>New campaign</h3>
        <div className="grid2">
          <label>Campaign name<input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
          <label>Product<input required value={form.product_name} onChange={(e) => setForm({ ...form, product_name: e.target.value })} /></label>
          <label>Objective<input value={form.objective} onChange={(e) => setForm({ ...form, objective: e.target.value })} /></label>
          <label>Target audience<input value={form.audience} onChange={(e) => setForm({ ...form, audience: e.target.value })} /></label>
        </div>
        <div className="row">
          {CHANNELS.map((ch) => (
            <label className="check" key={ch}>
              <input type="checkbox" checked={form.channels.includes(ch)} onChange={() => toggle(ch)} /> {ch}
            </label>
          ))}
        </div>
        {error && <div className="error">{error}</div>}
        <button className="primary">Create campaign</button>
      </form>
      {list.length === 0 && <p className="muted">No campaigns yet. Create one above, then upload its product document.</p>}
      {list.map((c) => <CampaignCard key={`${c.id}-${c.status}`} campaign={c} onChange={load} />)}
    </>
  );
}
