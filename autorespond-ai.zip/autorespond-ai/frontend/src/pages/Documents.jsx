import { useEffect, useState } from "react";
import api, { errorMessage } from "../services/api";

export default function Documents() {
  const [campaigns, setCampaigns] = useState([]);
  const [campaignId, setCampaignId] = useState("");
  const [docs, setDocs] = useState([]);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [q, setQ] = useState("");
  const [chunks, setChunks] = useState(null);

  useEffect(() => {
    api.get("/api/campaigns").then((r) => {
      setCampaigns(r.data);
      if (r.data[0]) setCampaignId(String(r.data[0].id));
    });
  }, []);
  const load = () => campaignId && api.get(`/api/documents?campaign_id=${campaignId}`).then((r) => setDocs(r.data));
  useEffect(() => { load(); setChunks(null); }, [campaignId]);

  const upload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const body = new FormData();
    body.append("campaign_id", campaignId);
    body.append("file", file);
    setBusy(true);
    setMsg("");
    try {
      await api.post("/api/documents/upload", body);
      setMsg(`${file.name} is now part of this campaign's knowledge base.`);
      load();
    } catch (err) {
      setMsg(errorMessage(err));
    } finally {
      setBusy(false);
      e.target.value = "";
    }
  };

  const remove = async (id) => { await api.delete(`/api/documents/${id}`); load(); };
  const test = async (e) => {
    e.preventDefault();
    const { data } = await api.get("/api/documents/search", { params: { campaign_id: campaignId, q } });
    setChunks(data.chunks);
  };

  if (campaigns.length === 0) return (<><h2>Product documents</h2><p className="muted">Create a campaign first, then add its product brochure here.</p></>);

  return (
    <>
      <h2>Product documents</h2>
      <section className="panel">
        <label>Campaign
          <select value={campaignId} onChange={(e) => setCampaignId(e.target.value)}>
            {campaigns.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </label>
        <label>Upload a PDF, DOCX or TXT brochure
          <input type="file" accept=".pdf,.docx,.txt,.md" disabled={busy} onChange={upload} />
        </label>
        {busy && <p className="muted">Reading and indexing the document…</p>}
        {msg && <div className="note">{msg}</div>}
      </section>
      <section className="panel">
        <h3>Uploaded documents</h3>
        {docs.length === 0 ? <p className="muted">Nothing uploaded for this campaign yet.</p> : (
          <table>
            <thead><tr><th>File</th><th>Status</th><th>Chunks</th><th /></tr></thead>
            <tbody>{docs.map((d) => (
              <tr key={d.id}><td>{d.filename}</td><td><span className={`tag ${d.status}`}>{d.status}</span></td><td>{d.chunk_count}</td>
                <td><button className="link" onClick={() => remove(d.id)}>Delete</button></td></tr>
            ))}</tbody>
          </table>
        )}
      </section>
      <section className="panel">
        <h3>Test the knowledge base</h3>
        <form className="row" onSubmit={test}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="e.g. Does it come with a 2-year warranty?" />
          <button>Search</button>
        </form>
        {chunks && (chunks.length === 0 ? <p className="muted">No matching text found.</p> : chunks.map((c, i) => <pre key={i} className="chunk">{c}</pre>))}
      </section>
    </>
  );
}
