import { useEffect, useState } from "react";
import api from "../services/api";

const TYPES = ["", "interested", "callback", "complaint"];

export default function Leads() {
  const [type, setType] = useState("");
  const [leads, setLeads] = useState([]);
  const load = () => api.get("/api/leads", { params: type ? { lead_type: type } : {} }).then((r) => setLeads(r.data));
  useEffect(() => { load(); }, [type]);
  const setStatus = async (id, status) => { await api.patch(`/api/leads/${id}`, { status }); load(); };

  return (
    <>
      <h2>Leads</h2>
      <div className="row">
        {TYPES.map((t) => (
          <button key={t || "all"} className={type === t ? "primary" : ""} onClick={() => setType(t)}>{t || "all"}</button>
        ))}
      </div>
      <section className="panel">
        {leads.length === 0 ? <p className="muted">No leads yet. Interested customers, callback requests and complaints appear here.</p> : (
          <table>
            <thead><tr><th>Customer</th><th>Contact</th><th>Type</th><th>Message</th><th>Campaign</th><th>Status</th></tr></thead>
            <tbody>{leads.map((l) => (
              <tr key={l.id}>
                <td>{l.customer_name}</td><td>{l.customer_email || l.customer_phone}</td>
                <td><span className="tag">{l.lead_type}</span></td><td>{l.note}</td><td>{l.campaign_name}</td>
                <td><select value={l.status} onChange={(e) => setStatus(l.id, e.target.value)}>
                  <option>open</option><option>contacted</option><option>closed</option></select></td>
              </tr>
            ))}</tbody>
          </table>
        )}
      </section>
    </>
  );
}
