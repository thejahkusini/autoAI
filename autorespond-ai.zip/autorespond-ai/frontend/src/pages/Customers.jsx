import { useEffect, useState } from "react";
import api, { errorMessage } from "../services/api";

const blank = { name: "", email: "", phone: "", consent: true };

export default function Customers() {
  const [list, setList] = useState([]);
  const [form, setForm] = useState(blank);
  const [msg, setMsg] = useState("");
  const load = () => api.get("/api/customers").then((r) => setList(r.data));
  useEffect(() => { load(); }, []);

  const add = async (e) => {
    e.preventDefault();
    setMsg("");
    try {
      await api.post("/api/customers", { ...form, email: form.email || null, phone: form.phone || null });
      setForm(blank);
      load();
    } catch (err) {
      setMsg(errorMessage(err));
    }
  };
  const importCsv = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const body = new FormData();
    body.append("file", file);
    try {
      const { data } = await api.post("/api/customers/import", body);
      setMsg(`Imported ${data.imported} customers.`);
      load();
    } catch (err) {
      setMsg(errorMessage(err));
    }
    e.target.value = "";
  };
  const toggleConsent = async (c) => { await api.patch(`/api/customers/${c.id}/consent`, null, { params: { consent: !c.consent } }); load(); };

  return (
    <>
      <h2>Customers</h2>
      <form className="panel" onSubmit={add}>
        <h3>Add a customer</h3>
        <div className="grid2">
          <label>Name<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
          <label>Email<input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label>
          <label>Phone (with country code)<input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+919876543210" /></label>
        </div>
        <label className="check"><input type="checkbox" checked={form.consent} onChange={(e) => setForm({ ...form, consent: e.target.checked })} /> This customer agreed to receive marketing messages</label>
        {msg && <div className="note">{msg}</div>}
        <button className="primary">Add customer</button>
      </form>
      <section className="panel">
        <label>Import a CSV (columns: name, email, phone, consent as yes/no)
          <input type="file" accept=".csv" onChange={importCsv} />
        </label>
      </section>
      <section className="panel">
        {list.length === 0 ? <p className="muted">No customers yet. Add one above or import a CSV.</p> : (
          <table>
            <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Consent</th><th>Status</th></tr></thead>
            <tbody>{list.map((c) => (
              <tr key={c.id}><td>{c.name}</td><td>{c.email}</td><td>{c.phone}</td>
                <td><button className="link" onClick={() => toggleConsent(c)}>{c.consent ? "Yes" : "No"}</button></td>
                <td>{c.unsubscribed ? <span className="tag failed">unsubscribed</span> : <span className="tag processed">active</span>}</td></tr>
            ))}</tbody>
          </table>
        )}
      </section>
    </>
  );
}
