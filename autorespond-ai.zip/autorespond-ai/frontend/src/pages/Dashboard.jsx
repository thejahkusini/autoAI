import { useEffect, useState } from "react";
import api from "../services/api";
import Bars from "../components/Bars.jsx";

export default function Dashboard() {
  const [data, setData] = useState(null);
  useEffect(() => {
    api.get("/api/analytics").then((r) => setData(r.data));
  }, []);
  if (!data) return <p className="muted">Loading…</p>;
  const t = data.totals;
  const stats = [
    ["Campaigns", t.campaigns],
    ["Messages sent", t.messages_sent],
    ["Customer replies", t.replies],
    ["Open leads", t.open_leads],
    ["Customers", t.customers],
    ["Unsubscribed", t.unsubscribed],
  ];
  return (
    <>
      <h2>Overview</h2>
      <div className="stats">
        {stats.map(([label, value]) => (
          <div className="stat" key={label}>
            <b>{value}</b>
            <span>{label}</span>
          </div>
        ))}
      </div>
      <div className="grid2">
        <section className="panel"><h3>What customers want</h3><Bars data={data.intents} empty="No replies yet. Try the Conversations page." /></section>
        <section className="panel"><h3>How customers feel</h3><Bars data={data.sentiments} /></section>
        <section className="panel"><h3>Leads by type</h3><Bars data={data.leads_by_type} /></section>
        <section className="panel"><h3>Messages sent by channel</h3><Bars data={data.channels} /></section>
      </div>
      <section className="panel">
        <h3>Campaign performance</h3>
        {data.campaigns.length === 0 ? (
          <p className="muted">Create your first campaign to see results here.</p>
        ) : (
          <table>
            <thead><tr><th>Campaign</th><th>Status</th><th>Sent</th><th>Failed</th><th>Replies</th><th>Leads</th></tr></thead>
            <tbody>
              {data.campaigns.map((c) => (
                <tr key={c.id}>
                  <td>{c.name}</td><td><span className={`tag ${c.status}`}>{c.status}</span></td>
                  <td>{c.sent}</td><td>{c.failed}</td><td>{c.replies}</td><td>{c.leads}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </>
  );
}
