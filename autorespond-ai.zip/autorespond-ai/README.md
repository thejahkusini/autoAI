# AutoRespond.ai: Agentic AI Marketing Automation (MVP)

React + FastAPI + SQLAlchemy + LangChain + LangGraph + RAG (ChromaDB).
Runs **fully offline by default** (`LLM_PROVIDER=mock`, `MESSAGING_MODE=mock`), so you can demo the
whole flow before adding any API keys.

## What works

1. Register / log in (JWT; the first account is admin)
2. Create a campaign (product, objective, audience, channels)
3. Upload a product PDF/DOCX/TXT -> text extraction -> chunking -> embeddings -> ChromaDB
4. Generate campaign copy (LangGraph: retrieve -> generate -> validate), edit, approve, launch
5. Add customers (consent tracked) or import CSV; launch sends via a mock Email/WhatsApp/SMS service
6. Simulate or receive customer replies (webhooks) -> LangGraph workflow:
   intent -> sentiment -> route (opt-out / callback / escalate / RAG answer) -> reply
7. Leads (interested, callback, complaint) and an analytics dashboard

## Run it (VS Code terminal)

Requires Python 3.10+ and Node.js 18+.

### Backend
```bash
cd backend
python -m venv venv
# Windows:  .\venv\Scripts\activate        macOS/Linux:  source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
Check http://localhost:8000/api/health and the API docs at http://localhost:8000/docs.
`backend/.env` is already created from `.env.example` (SQLite, mock mode).

### Frontend (second terminal)
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173, register, and follow the demo below.

## 5-minute demo

1. **Campaigns** -> create "Diwali Smart TV Promotion", product "Smart TV", channel WhatsApp.
2. **Product documents** -> upload a brochure (a .txt with price, 2-year warranty, return policy is fine).
   Use "Test the knowledge base" to see retrieved chunks.
3. **Customers** -> add a customer with phone `+919876543210` and consent ticked.
4. **Campaigns** -> Generate message -> Approve -> Launch (watch the backend terminal print `[MOCK WHATSAPP]`).
5. **Conversations** -> pick the customer and try:
   - "Does this TV come with a 2-year warranty?"  -> RAG answer
   - "I'm interested, tell me more"                -> lead created
   - "Please call me"                              -> callback lead
   - "Your product stopped working"                -> escalated complaint
   - "Stop sending messages"                       -> immediately opted out
6. **Leads** and **Overview** update automatically.

## Switch on real AI

Edit `backend/.env`:
```
LLM_PROVIDER=gemini          # or azure | cohere
EMBEDDING_PROVIDER=gemini    # same options
GOOGLE_API_KEY=...
```
Then `pip install -r requirements-llm.txt` and restart. Optional `LLM_FALLBACK_PROVIDER` retries on another provider.
**If you change `EMBEDDING_PROVIDER`, re-upload your documents** (vectors from different models are not compatible;
each provider uses its own Chroma collection).

## Real messaging

Set `MESSAGING_MODE=live` and fill the SMTP / Twilio values (SMS and WhatsApp use Twilio in this template).
Point your provider's inbound webhook at:
`POST /api/webhooks/{email|whatsapp|sms}` (JSON `{from, message, campaign_id?}` or Twilio form fields).
Use a public URL (e.g. ngrok) in development, set `WEBHOOK_SECRET` (sent as `X-Webhook-Secret`),
and add provider signature verification before production.
WhatsApp outbound campaigns require provider-approved templates.

## PostgreSQL, Redis and Celery (optional)

```bash
docker compose up -d
```
Set `DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost:5432/autorespond`, `USE_CELERY=true`, then:
```bash
celery -A app.tasks.celery_app worker --loglevel=info --pool=solo
```

## Project layout

```
backend/app
  main.py            FastAPI app, routers, CORS
  api/               auth, campaigns, documents, customers, messages, leads, analytics, webhooks
  agents/            intent, sentiment, campaign, response
  workflows/         response_graph.py (customer replies), campaign_graph.py (copy generation)
  rag/               ingestion.py, embeddings.py, retrieval.py
  services/          llm_service, email/sms/whatsapp, messaging, campaign_runner, conversation_service
  database/          connection.py, models.py
frontend/src         pages/, components/, services/api.js
```

## Safety rules built in

- Opt-out ("stop", "unsubscribe"...) is detected by rules, never by an LLM, and suppresses the customer immediately.
- Consent and opt-out are re-checked on every campaign dispatch; duplicate sends are prevented.
- Campaign content must be approved before launch; editing content resets approval.
- Customer messages and documents are passed to the LLM as untrusted data.
- Questions the knowledge base can't answer are flagged for a human instead of guessed.

## Known limits of this MVP

- Tables are created with `create_all`; add Alembic migrations before production.
- Auth token lives in localStorage; use httpOnly cookies for production hardening.
- Scanned (image-only) PDFs need OCR, which isn't included.
- Mock embeddings match on shared words only; use a real embedding provider for semantic search.
- This code was syntax-checked but not run end to end in the environment that generated it, so expect to fix small issues on first run.
